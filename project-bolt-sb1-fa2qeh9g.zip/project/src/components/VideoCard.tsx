import { useEffect, useState, useRef } from 'react';
import { Loader2, AlertTriangle, CheckCircle2, Download, Heart, Eye } from 'lucide-react';
import { supabase, type Video } from '@/lib/supabase';

const PROGRESS_STAGES = ['Starting...', 'Generating...', 'Almost done...'];

function stageFor(elapsed: number): string {
  if (elapsed < 60_000) return PROGRESS_STAGES[0];
  if (elapsed < 180_000) return PROGRESS_STAGES[1];
  return PROGRESS_STAGES[2];
}

export default function VideoCard({ video }: { video: Video }) {
  const [elapsed, setElapsed] = useState(Date.now() - new Date(video.created_at).getTime());
  const [likes, setLikes] = useState(video.likes ?? 0);
  const [views, setViews] = useState(video.views ?? 0);
  const [liked, setLiked] = useState(false);
  const viewRecorded = useRef(false);
  const isProcessing = video.status === 'processing';

  useEffect(() => {
    if (!isProcessing) return;
    const t = setInterval(() => setElapsed(Date.now() - new Date(video.created_at).getTime()), 1000);
    return () => clearInterval(t);
  }, [isProcessing, video.created_at]);

  // Count a view once when a completed video starts playing
  useEffect(() => {
    if (isProcessing || video.status !== 'completed' || !video.video_url || viewRecorded.current) return;
    viewRecorded.current = true;
    supabase
      .rpc('record_view', { p_video_id: video.id })
      .then(({ data }) => { if (typeof data === 'number') setViews(data); })
      .catch(() => {});
  }, [isProcessing, video.status, video.video_url, video.id]);

  const like = async () => {
    if (liked) return;
    setLiked(true);
    setLikes((n) => n + 1);
    const { data } = await supabase.rpc('like_video', { p_video_id: video.id });
    if (typeof data === 'number') setLikes(data);
  };

  return (
    <div className="bg-[#141018]/80 border border-white/10 rounded-2xl overflow-hidden flex flex-col">
      {isProcessing ? (
        <div className="aspect-video bg-black/40 flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-gold-400" />
          <p className="text-sm text-gold-200 font-medium">{stageFor(elapsed)}</p>
          <p className="text-xs text-zinc-500">{Math.floor(elapsed / 1000)}s elapsed</p>
        </div>
      ) : video.status === 'completed' && video.video_url ? (
        <video src={video.video_url} controls playsInline className="w-full aspect-video bg-black" />
      ) : (
        <div className="aspect-video bg-red-500/5 flex flex-col items-center justify-center gap-2 px-6">
          <AlertTriangle className="w-8 h-8 text-red-400" />
          <p className="text-sm text-red-300 text-center break-words">{video.error_message ?? 'Generation failed.'}</p>
        </div>
      )}

      <div className="p-4 space-y-2 flex-1 flex flex-col">
        <p className="text-sm text-zinc-200 line-clamp-2 flex-1">{video.prompt}</p>
        <div className="flex items-center justify-between gap-2">
          <div className="flex flex-wrap gap-1.5">
            <span className="text-[11px] bg-white/5 border border-white/10 text-zinc-400 px-2 py-0.5 rounded-full">{video.style}</span>
            <span className="text-[11px] bg-white/5 border border-white/10 text-zinc-400 px-2 py-0.5 rounded-full">{video.duration}</span>
            <span className="text-[11px] bg-white/5 border border-white/10 text-zinc-400 px-2 py-0.5 rounded-full">{video.aspect_ratio}</span>
          </div>
          <div className="flex items-center gap-2">
            {video.status === 'completed' && (
              <>
                <button
                  onClick={() => void like()}
                  className={`flex items-center gap-1 text-xs font-medium px-2.5 py-1.5 rounded-lg border transition ${
                    liked
                      ? 'text-gold-300 bg-gold-500/15 border-gold-500/40'
                      : 'text-zinc-400 hover:text-gold-300 bg-white/5 border-white/10 hover:border-gold-500/30'
                  }`}
                  aria-label="Like video"
                >
                  <Heart className={`w-3.5 h-3.5 ${liked ? 'fill-gold-400' : ''}`} />
                  {likes}
                </button>
                <span className="flex items-center gap-1 text-xs text-zinc-500" title="Views">
                  <Eye className="w-3.5 h-3.5" />
                  {views}
                </span>
                {video.video_url && (
                  <a
                    href={video.video_url}
                    target="_blank"
                    rel="noreferrer"
                    download
                    className="flex items-center gap-1.5 text-xs font-medium text-gold-300 hover:text-gold-200 bg-gold-500/10 border border-gold-500/25 px-3 py-1.5 rounded-lg transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </a>
                )}
              </>
            )}
            {video.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
          </div>
        </div>
      </div>
    </div>
  );
}
