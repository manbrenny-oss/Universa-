import { Home, Repeat, Sparkles, Radio, MessageCircle, Wallet, User } from 'lucide-react';

export type TabId = 'home' | 'swap' | 'create' | 'live' | 'chat' | 'wallet' | 'profile';

const TABS: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'swap', label: 'Swap', icon: Repeat },
  { id: 'create', label: 'Create', icon: Sparkles },
  { id: 'live', label: 'Live', icon: Radio },
  { id: 'chat', label: 'Chat', icon: MessageCircle },
  { id: 'wallet', label: 'Wallet', icon: Wallet },
  { id: 'profile', label: 'Profile', icon: User },
];

export default function BottomNav({ active, onChange }: { active: TabId; onChange: (tab: TabId) => void }) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 border-t border-white/10 bg-[#0d0817]/90 backdrop-blur-lg">
      <div className="max-w-5xl mx-auto px-1 pb-[env(safe-area-inset-bottom)]">
        <div className="grid grid-cols-7">
          {TABS.map(({ id, label, icon: Icon }) => {
            const isActive = active === id;
            return (
              <button
                key={id}
                onClick={() => onChange(id)}
                className={`flex flex-col items-center justify-center gap-0.5 py-2.5 transition-colors duration-150 ${
                  isActive ? 'text-gold-400' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <span
                  className={`flex items-center justify-center w-9 h-7 rounded-full transition-all duration-200 ${
                    isActive ? 'bg-gold-500/15' : ''
                  }`}
                >
                  <Icon className="w-5 h-5" strokeWidth={isActive ? 2.4 : 2} />
                </span>
                <span className="text-[10px] font-medium">{label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
