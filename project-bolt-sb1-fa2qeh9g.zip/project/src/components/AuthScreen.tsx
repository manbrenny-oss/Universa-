import { useEffect, useState } from 'react';
import { Loader2, Clapperboard } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getAccessToken, callFunction } from '@/lib/api';

export default function AuthScreen({ onSignedIn }: { onSignedIn: () => void }) {
  const [mode, setMode] = useState<'signup' | 'signin'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Resume Paystack verification after returning from checkout
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (params.get('payment') === 'success' && ref) {
      params.delete('payment');
      params.delete('ref');
      window.history.replaceState({}, '', `${window.location.pathname}${params.toString() ? `?${params}` : ''}`);
      void (async () => {
        try {
          const token = await getAccessToken();
          await callFunction('paystack-verify', { reference: ref }, token);
        } catch {
          // Wallet page will also attempt verification on next visit
        }
      })();
    }
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error: authError } =
      mode === 'signup'
        ? await supabase.auth.signUp({ email, password })
        : await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (authError) {
      setError(authError.message);
      return;
    }
    onSignedIn();
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute -top-40 -left-40 w-[500px] h-[500px] bg-purple-700/25 rounded-full blur-3xl" />
      <div className="absolute -bottom-40 -right-40 w-[500px] h-[500px] bg-gold-600/20 rounded-full blur-3xl" />

      <div className="relative w-full max-w-md">
        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-700 to-gold-500 flex items-center justify-center shadow-lg shadow-gold-500/25">
            <Clapperboard className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight bg-gradient-to-r from-purple-300 via-gold-300 to-gold-400 bg-clip-text text-transparent">
            UNIVERSA
          </h1>
        </div>
        <p className="text-center text-sm text-zinc-400 mb-8">Your Whole World In One App</p>

        <div className="bg-[#141018]/80 backdrop-blur border border-white/10 rounded-2xl p-8 shadow-2xl shadow-black/40">
          <div className="flex gap-2 p-1 bg-black/30 rounded-xl mb-6">
            {(['signup', 'signin'] as const).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(null); }}
                className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                  mode === m
                    ? 'bg-gradient-to-r from-purple-700 to-gold-500 text-white shadow-md shadow-gold-600/30'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {m === 'signup' ? 'Sign Up' : 'Sign In'}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-1.5">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20 transition"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1.5">Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20 transition"
              />
            </div>

            {error && (
              <p className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 shadow-lg shadow-gold-600/25 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === 'signup' ? 'Create Account — 3 Free Coins' : 'Sign In'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
