import { useEffect, useState, useCallback } from 'react';
import { LogOut, Video as VideoIcon, Repeat, Coins, Radio, Loader2 } from 'lucide-react';
import { supabase, type Video, type LiveRoom } from '@/lib/supabase';

export default function ProfilePage({
  email,
  coins,
  onSignOut,
  onOpenCreate,
}: {
  email: string;
  coins: number | null;
  onSignOut: () => void;
  onOpenCreate: () => void;
}) {
  const [videoCount, setVideoCount] = useState<number | null>(null);
  const [characterCount, setCharacterCount] = useState<number | null>(null);
  const [liveCount, setLiveCount] = useState<number | null>(null);
  const [myVideos, setMyVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const [videosRes, charactersRes, liveRes] = await Promise.all([
        supabase.from('videos').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(6),
        supabase.from('characters').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
        supabase.from('live_rooms').select('id', { count: 'exact', head: true }).eq('host_id', user.id).eq('status', 'live'),
      ]);
      setMyVideos((videosRes.data ?? []) as Video[]);
      setVideoCount(videosRes.data?.length ?? 0);
      setCharacterCount(charactersRes.count ?? 0);
      setLiveCount(liveRes.count ?? 0);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const stats = [
    { icon: VideoIcon, label: 'Videos', value: videoCount },
    { icon: Repeat, label: 'Characters', value: characterCount },
    { icon: Radio, label: 'Live Rooms', value: liveCount },
    { icon: Coins, label: 'Coins', value: coins },
  ];

  return (
    <div className="space-y-8">
      <section className="rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-br from-purple-900/60 via-[#141018] to-[#0A0A0A] p-6 sm:p-8 relative">
        <div className="absolute -top-16 -right-16 w-48 h-48 bg-gold-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-700 to-gold-500 flex items-center justify-center text-2xl font-bold shadow-lg shadow-gold-600/30">
            {email ? email.charAt(0).toUpperCase() : 'U'}
          </div>
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-widest text-gold-400 font-semibold">UNIVERSA Creator</p>
            <p className="text-lg font-semibold truncate">{email || 'You'}</p>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {stats.map(({ icon: Icon, label, value }) => (
          <div key={label} className="bg-[#141018]/80 border border-white/10 rounded-2xl p-4 text-center">
            <Icon className="w-5 h-5 text-gold-400 mx-auto mb-2" />
            <p className="text-xl font-bold">{loading ? '…' : (value ?? 0)}</p>
            <p className="text-[11px] text-zinc-500 mt-0.5">{label}</p>
          </div>
        ))}
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Recent Videos</h2>
          <button onClick={onOpenCreate} className="text-sm text-gold-400 hover:text-gold-300 transition">
            Create new
          </button>
        </div>
        {myVideos.length === 0 ? (
          <div className="border border-dashed border-white/10 rounded-2xl py-12 text-center text-zinc-500">
            <VideoIcon className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p>No videos yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {myVideos.map((v) => (
              <div key={v.id} className="aspect-video rounded-xl overflow-hidden border border-white/10 bg-black/40">
                {v.status === 'completed' && v.video_url ? (
                  <video src={v.video_url} className="w-full h-full object-cover" muted playsInline />
                ) : v.status === 'processing' ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <Loader2 className="w-5 h-5 animate-spin text-gold-400" />
                  </div>
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-red-400 text-xs">Failed</div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <button
          onClick={onSignOut}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-medium text-red-400 bg-red-500/10 border border-red-500/20 hover:bg-red-500/15 transition"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </section>
    </div>
  );
}
