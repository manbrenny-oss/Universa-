import { useEffect, useState, useCallback } from 'react';
import { Loader2, Plus, Trash2, Repeat, Lock, Globe, Coins } from 'lucide-react';
import { supabase, type Character } from '@/lib/supabase';
import { getAccessToken, callFunction } from '@/lib/api';

export default function SwapPage({
  onOpenCreate,
}: {
  onOpenCreate: () => void;
}) {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [imageInput, setImageInput] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Character | null>(null);
  const [coins, setCoins] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('characters')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(30);
    setCharacters((data ?? []) as Character[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    void (async () => {
      const { data } = await supabase.from('profiles').select('credits').limit(1).maybeSingle();
      if (data) setCoins(data.credits);
    })();
  }, [load]);

  const createCharacter = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) { setError('Give your character a name.'); return; }
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Please sign in first.');
      const { error: insertError } = await supabase.from('characters').insert({
        name: name.trim(),
        tagline: tagline.trim() || null,
        image_url: imageInput.trim() || null,
        is_public: isPublic,
      });
      if (insertError) throw new Error(insertError.message);
      setName(''); setTagline(''); setImageInput('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save character.');
    } finally {
      setSaving(false);
    }
  };

  const deleteCharacter = async (id: string) => {
    await supabase.from('characters').delete().eq('id', id);
    if (selected?.id === id) setSelected(null);
    await load();
  };

  const SWAP_COST = 50;

  const swapPreview = async (character: Character) => {
    setError(null);
    if ((coins ?? 0) < SWAP_COST) {
      setError(`You need ${SWAP_COST} Coins to swap. Earn more in the Earn tab of your Wallet.`);
      return;
    }
    const { data: spent } = await supabase.rpc('spend_coins', {
      p_amount: SWAP_COST,
      p_kind: 'swap_spend',
      p_description: `Character swap: ${character.name}`,
    });
    if (spent === false) {
      setError(`You need ${SWAP_COST} Coins to swap. Earn more in the Earn tab of your Wallet.`);
      return;
    }
    setCoins((c) => (c ?? SWAP_COST) - SWAP_COST);
    setSelected(character);
    try {
      const token = await getAccessToken();
      await callFunction(
        'generate-video',
        { prompt: `Character swap: transform the video subject into "${character.name}" — ${character.tagline ?? 'signature look'}. Style: Cinematic. Duration: 5s. Aspect ratio: 9:16.`, style: 'Cinematic', duration: '5s', aspect_ratio: '9:16' },
        token,
      );
    } catch {
      // Preview generation is optional — user can use Create tab instead
    }
  };

  return (
    <div className="space-y-8">
      <section>
        <div className="flex items-center gap-2 mb-1">
          <Repeat className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-semibold">Character Swap Studio</h1>
        </div>
        <p className="text-sm text-zinc-400">Create a persona, then swap yourself or your videos into it.</p>
      </section>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm text-red-300">{error}</div>
      )}

      <section className="bg-[#141018]/80 border border-white/10 rounded-2xl p-6">
        <h2 className="text-sm font-semibold text-zinc-200 mb-4 flex items-center gap-2">
          <Plus className="w-4 h-4 text-gold-400" />
          New Character
        </h2>
        <form onSubmit={createCharacter} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-1.5">Name</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Neon Ninja"
                className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20 transition text-sm"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1.5">Tagline</label>
              <input
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="Short description of the look"
                className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20 transition text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm text-zinc-300 mb-1.5">Character image URL (optional)</label>
            <input
              value={imageInput}
              onChange={(e) => setImageInput(e.target.value)}
              placeholder="https://..."
              className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20 transition text-sm"
            />
          </div>
          <label className="flex items-center gap-2 text-sm text-zinc-300">
            <input
              type="checkbox"
              checked={isPublic}
              onChange={(e) => setIsPublic(e.target.checked)}
              className="w-4 h-4 rounded accent-gold-500"
            />
            Share to the community feed
          </label>

          {error && (
            <p className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{error}</p>
          )}

          <button
            type="submit"
            disabled={saving}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 shadow-lg shadow-gold-600/25 transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            Save Character
          </button>
        </form>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Your Characters</h2>
          <span className="flex items-center gap-1.5 text-xs text-gold-300 bg-gold-500/10 border border-gold-500/25 px-3 py-1 rounded-full">
            <Coins className="w-3.5 h-3.5" />
            Swap costs {SWAP_COST} Coins
          </span>
        </div>
        {loading ? (
          <div className="py-12 flex justify-center"><Loader2 className="w-7 h-7 animate-spin text-gold-500" /></div>
        ) : characters.length === 0 ? (
          <div className="border border-dashed border-white/10 rounded-2xl py-14 text-center text-zinc-500">
            <Repeat className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p>No characters yet. Create your first one above.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {characters.map((c) => (
              <div
                key={c.id}
                className={`rounded-2xl border overflow-hidden transition-all duration-200 ${
                  selected?.id === c.id ? 'border-gold-500/60 ring-2 ring-gold-500/25' : 'border-white/10 hover:border-white/25'
                } bg-[#141018]/80`}
              >
                <div className="aspect-square bg-purple-900/30">
                  {c.image_url ? (
                    <img src={c.image_url} alt={c.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-3xl font-bold text-gold-400/50">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="p-3 space-y-2">
                  <div className="flex items-center justify-between gap-1">
                    <p className="text-sm font-medium truncate">{c.name}</p>
                    {c.is_public
                      ? <Globe className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                      : <Lock className="w-3.5 h-3.5 text-zinc-500 shrink-0" />}
                  </div>
                  {c.tagline && <p className="text-[11px] text-zinc-500 line-clamp-1">{c.tagline}</p>}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => void swapPreview(c)}
                      className="flex-1 text-xs font-medium text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 px-3 py-1.5 rounded-lg transition"
                    >
                      Swap In
                    </button>
                    <button
                      onClick={() => void deleteCharacter(c.id)}
                      className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition"
                      aria-label={`Delete ${c.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {selected && (
        <section className="bg-gold-500/10 border border-gold-500/20 rounded-2xl p-5 text-sm text-gold-200">
          <p className="font-medium mb-1">"{selected.name}" is ready to swap — {SWAP_COST} Coins used.</p>
          <p className="text-gold-200/80">
            Head to the Create tab — a 9:16 video with this character's look has been queued and will appear in your videos.
          </p>
        </section>
      )}
    </div>
  );
}
