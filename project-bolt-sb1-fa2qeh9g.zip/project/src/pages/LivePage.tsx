import { useEffect, useState, useCallback } from 'react';
import { Loader2, Radio, Plus, Eye, LogOut, Users } from 'lucide-react';
import { supabase, type LiveRoom } from '@/lib/supabase';

const HEARTBEAT_MS = 20_000;

export default function LivePage() {
  const [rooms, setRooms] = useState<LiveRoom[]>([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [watchingId, setWatchingId] = useState<string | null>(null);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('live_rooms')
      .select('*')
      .eq('status', 'live')
      .order('started_at', { ascending: false })
      .limit(30);
    setRooms((data ?? []) as LiveRoom[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    supabase.auth.getUser().then(({ data: { user } }) => setCurrentUserId(user?.id ?? null));
  }, [load]);

  const startRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!title.trim()) { setError('Give your live room a title.'); return; }
    setStarting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Please sign in first.');
      const { error: insertError } = await supabase.from('live_rooms').insert({ title: title.trim() });
      if (insertError) throw new Error(insertError.message);
      setTitle('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not start your room.');
    } finally {
      setStarting(false);
    }
  };

  const endRoom = async (id: string) => {
    await supabase
      .from('live_rooms')
      .update({ status: 'ended', ended_at: new Date().toISOString() })
      .eq('id', id);
    if (watchingId === id) setWatchingId(null);
    await load();
  };

  // Join/leave presence + viewer count heartbeat
  useEffect(() => {
    if (!watchingId || !currentUserId) return;
    const join = async () => {
      await supabase.from('live_presence').upsert(
        { room_id: watchingId, user_id: currentUserId, joined_at: new Date().toISOString() },
        { onConflict: 'room_id,user_id' },
      );
      const { count } = await supabase
        .from('live_presence')
        .select('*', { count: 'exact', head: true })
        .eq('room_id', watchingId);
      await supabase.from('live_rooms').update({ viewers: count ?? 1 }).eq('id', watchingId);
    };
    void join();
    const t = setInterval(() => void join(), HEARTBEAT_MS);
    return () => {
      clearInterval(t);
      void supabase.from('live_presence').delete().eq('room_id', watchingId).eq('user_id', currentUserId);
    };
  }, [watchingId, currentUserId]);

  const watching = rooms.find((r) => r.id === watchingId) ?? null;

  return (
    <div className="space-y-8">
      <section>
        <div className="flex items-center gap-2 mb-1">
          <Radio className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-semibold">Live</h1>
        </div>
        <p className="text-sm text-zinc-400">Join a live room or start your own broadcast.</p>
      </section>

      <section className="bg-[#141018]/80 border border-white/10 rounded-2xl p-5">
        <h2 className="text-sm font-semibold text-zinc-200 mb-3 flex items-center gap-2">
          <Plus className="w-4 h-4 text-gold-400" />
          Go Live
        </h2>
        <form onSubmit={startRoom} className="flex flex-col sm:flex-row gap-3">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="What's your live room about?"
            className="flex-1 bg-black/30 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20 transition text-sm"
          />
          <button
            type="submit"
            disabled={starting}
            className="px-6 py-2.5 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 shadow-lg shadow-gold-600/25 transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {starting && <Loader2 className="w-4 h-4 animate-spin" />}
            Start
          </button>
        </form>
        {error && <p className="text-sm text-red-400 mt-3">{error}</p>}
      </section>

      {watching && (
        <section className="rounded-2xl border border-gold-500/30 bg-gold-500/5 p-5">
          <div className="flex items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-gold-500" />
              </span>
              <p className="text-sm font-semibold text-gold-200">{watching.title}</p>
            </div>
            <button
              onClick={() => setWatchingId(null)}
              className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white transition px-3 py-1.5 rounded-lg hover:bg-white/5"
            >
              <LogOut className="w-3.5 h-3.5" />
              Leave
            </button>
          </div>
          <div className="aspect-video bg-black/50 rounded-xl flex flex-col items-center justify-center gap-2">
            <Eye className="w-7 h-7 text-gold-400/60" />
            <p className="text-sm text-zinc-400">Watching "{watching.title}"</p>
            <p className="text-xs text-zinc-500 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              {watching.viewers} in the room
            </p>
          </div>
        </section>
      )}

      <section>
        <h2 className="text-lg font-semibold mb-4">Live Now</h2>
        {loading ? (
          <div className="py-12 flex justify-center"><Loader2 className="w-7 h-7 animate-spin text-gold-500" /></div>
        ) : rooms.length === 0 ? (
          <div className="border border-dashed border-white/10 rounded-2xl py-14 text-center text-zinc-500">
            <Radio className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p>No one is live right now. Start a room above!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {rooms.map((room) => (
              <div key={room.id} className="bg-[#141018]/80 border border-white/10 rounded-2xl p-5 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{room.title}</p>
                  <p className="text-xs text-zinc-500 mt-1 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5" />
                    {room.viewers} watching
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setWatchingId(room.id)}
                    className="text-xs font-medium text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 px-4 py-1.5 rounded-lg transition"
                  >
                    Watch
                  </button>
                  {room.host_id === currentUserId && (
                    <button
                      onClick={() => void endRoom(room.id)}
                      className="text-xs text-zinc-400 hover:text-red-400 transition px-2 py-1.5"
                    >
                      End
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
