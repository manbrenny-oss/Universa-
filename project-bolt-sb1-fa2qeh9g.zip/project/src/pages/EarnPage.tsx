import { useEffect, useState, useCallback } from 'react';
import { Gift, Users, Video, Heart, Eye, LogIn, Coins, Check, Copy, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const EARN_RULES = [
  { icon: Video, label: 'Post a video', reward: 10, note: 'Every video you create and post' },
  { icon: Heart, label: '100 likes on a video', reward: 20, note: 'Auto-awarded when a video hits 100 likes' },
  { icon: Eye, label: '1,000 views on a video', reward: 50, note: 'Auto-awarded when a video hits 1,000 views' },
  { icon: LogIn, label: 'Daily login', reward: 5, note: 'Sign in once a day — claim below' },
  { icon: Users, label: 'Invite a friend', reward: 100, note: 'Share your invite link below' },
];

export default function EarnPage({ onCoinsChanged }: { onCoinsChanged: (c: number) => void }) {
  const [claimedToday, setClaimedToday] = useState(false);
  const [claiming, setClaiming] = useState(false);
  const [inviteLink, setInviteLink] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const loadInvite = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data: existing } = await supabase
      .from('coin_ledger')
      .select('ref_id')
      .eq('user_id', user.id)
      .eq('kind', 'daily_login')
      .gte('created_at', new Date().toISOString().slice(0, 10))
      .limit(1);
    if (existing && existing.length > 0) setClaimedToday(true);
    setInviteLink(`${window.location.origin}/?ref=${user.id}`);
  }, []);

  useEffect(() => { void loadInvite(); }, [loadInvite]);

  const claimDaily = async () => {
    setClaiming(true);
    setError(null);
    setNotice(null);
    try {
      const { data, error: rpcError } = await supabase.rpc('award_daily_login');
      if (rpcError) throw new Error(rpcError.message);
      if (data === 0) {
        setClaimedToday(true);
        setNotice('You already claimed today. Come back tomorrow!');
      } else {
        setClaimedToday(true);
        setNotice('+5 Coins added!');
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: profile } = await supabase.from('profiles').select('credits').eq('id', user.id).maybeSingle();
          if (profile) onCoinsChanged(profile.credits);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not claim bonus.');
    } finally {
      setClaiming(false);
    }
  };

  const copyInvite = async () => {
    await navigator.clipboard.writeText(inviteLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      <section>
        <div className="flex items-center gap-2 mb-1">
          <Gift className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-semibold">Earn Coins</h1>
        </div>
        <p className="text-sm text-zinc-400">Grow your balance for free — every action below pays out instantly.</p>
      </section>

      {notice && (
        <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-4 py-3">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <p className="text-sm text-emerald-200">{notice}</p>
        </div>
      )}
      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm text-red-300">{error}</div>
      )}

      <section className="bg-gradient-to-br from-purple-900/60 via-[#141018] to-[#0A0A0A] border border-gold-500/25 rounded-2xl p-6 flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-gold-200">Daily login bonus</p>
          <p className="text-xs text-zinc-400 mt-1">5 Coins, every single day</p>
        </div>
        <button
          onClick={() => void claimDaily()}
          disabled={claimedToday || claiming}
          className="shrink-0 px-5 py-2.5 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-600 hover:to-gold-400 shadow-lg shadow-gold-600/25 transition-all duration-200 disabled:opacity-50 flex items-center gap-2"
        >
          {claiming && <Loader2 className="w-4 h-4 animate-spin" />}
          {claimedToday ? (
            <>
              <Check className="w-4 h-4" />
              Claimed
            </>
          ) : (
            <>
              <Coins className="w-4 h-4" />
              Claim 5
            </>
          )}
        </button>
      </section>

      <section>
        <h2 className="text-lg font-semibold mb-4">Ways to Earn</h2>
        <div className="space-y-3">
          {EARN_RULES.map(({ icon: Icon, label, reward, note }) => (
            <div key={label} className="bg-[#141018]/80 border border-white/10 rounded-2xl p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-purple-800/50 border border-white/10 flex items-center justify-center shrink-0">
                <Icon className="w-5 h-5 text-gold-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{label}</p>
                <p className="text-xs text-zinc-500 mt-0.5">{note}</p>
              </div>
              <span className="shrink-0 flex items-center gap-1.5 text-sm font-bold text-gold-300 bg-gold-500/10 border border-gold-500/25 px-3 py-1.5 rounded-full">
                <Coins className="w-4 h-4" />
                +{reward}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-lg font-semibold mb-1">Invite a Friend</h2>
        <p className="text-sm text-zinc-400 mb-4">They sign up with your link — you get 100 Coins.</p>
        <div className="bg-[#141018]/80 border border-white/10 rounded-2xl p-4 flex items-center gap-3">
          <input
            readOnly
            value={inviteLink}
            className="flex-1 bg-black/30 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-zinc-300 focus:outline-none"
          />
          <button
            onClick={() => void copyInvite()}
            className="shrink-0 flex items-center gap-1.5 text-sm font-semibold text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-600 hover:to-gold-400 px-4 py-2.5 rounded-xl transition"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </section>
    </div>
  );
}
