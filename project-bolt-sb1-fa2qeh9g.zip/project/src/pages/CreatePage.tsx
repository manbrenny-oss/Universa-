import { useEffect, useRef, useState, useCallback } from 'react';
import { Loader2, Film, AlertTriangle } from 'lucide-react';
import VideoCard from '@/components/VideoCard';
import { getAccessToken, callFunction, fetchVideos, fetchProfile } from '@/lib/api';
import { supabase, type Video } from '@/lib/supabase';

const STYLES = ['Cinematic', 'Anime', 'Realistic', '3D Render', 'Documentary'] as const;
const DURATIONS = ['5s', '10s'] as const;
const ASPECTS = [
  { value: '16:9', label: '16:9 Landscape' },
  { value: '9:16', label: '9:16 Portrait' },
] as const;

const POLL_INTERVAL = 10_000;
const TIMEOUT_MS = 5 * 60 * 1000;

const PROGRESS_STAGES = ['Starting...', 'Generating...', 'Almost done...'];

function stageFor(elapsed: number): string {
  if (elapsed < 60_000) return PROGRESS_STAGES[0];
  if (elapsed < 180_000) return PROGRESS_STAGES[1];
  return PROGRESS_STAGES[2];
}

export default function CreatePage({
  onCreditsChanged,
}: {
  onCreditsChanged: (c: number) => void;
}) {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState<(typeof STYLES)[number]>('Cinematic');
  const [duration, setDuration] = useState<(typeof DURATIONS)[number]>('5s');
  const [aspect, setAspect] = useState<'16:9' | '9:16'>('16:9');

  const [videos, setVideos] = useState<Video[]>([]);
  const [generating, setGenerating] = useState(false);
  const [genStartedAt, setGenStartedAt] = useState<number | null>(null);
  const [genError, setGenError] = useState<string | null>(null);
  const [loadingVideos, setLoadingVideos] = useState(false);

  const pollTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadVideos = useCallback(async () => {
    setLoadingVideos(true);
    try {
      setVideos(await fetchVideos());
    } finally {
      setLoadingVideos(false);
    }
  }, []);

  useEffect(() => { void loadVideos(); void fetchProfile(); }, [loadVideos]);

  const stopPolling = useCallback(() => {
    if (pollTimer.current) {
      clearInterval(pollTimer.current);
      pollTimer.current = null;
    }
  }, []);

  useEffect(() => stopPolling, [stopPolling]);

  const checkStatus = useCallback(async (videoId: string, startedAt: number) => {
    try {
      const token = await getAccessToken();
      const body = await callFunction<{ video?: Video }>('check-video-status', { videoId }, token).catch(() => null);
      if (!body?.video) {
        if (Date.now() - startedAt > TIMEOUT_MS) {
          stopPolling(); setGenerating(false); setGenStartedAt(null);
          setGenError('Generation timed out after 5 minutes.');
        }
        return;
      }
      const v: Video = body.video;
      setVideos((prev) => prev.map((p) => (p.id === v.id ? v : p)));
      if (v.status === 'completed') {
        stopPolling(); setGenerating(false); setGenStartedAt(null);
        const { data } = await supabase.from('profiles').select('credits').limit(1).maybeSingle();
        if (data) onCreditsChanged(data.credits);
      } else if (v.status === 'failed') {
        stopPolling(); setGenerating(false); setGenStartedAt(null);
        setGenError(v.error_message ?? 'Generation failed.');
      } else if (Date.now() - startedAt > TIMEOUT_MS) {
        stopPolling(); setGenerating(false); setGenStartedAt(null);
        setGenError('Generation timed out after 5 minutes.');
      }
    } catch {
      // transient network error — keep polling until timeout
    }
  }, [stopPolling, onCreditsChanged]);

  const startPolling = useCallback((videoId: string, startedAt: number) => {
    stopPolling();
    pollTimer.current = setInterval(() => checkStatus(videoId, startedAt), POLL_INTERVAL);
    checkStatus(videoId, startedAt);
  }, [checkStatus, stopPolling]);

  useEffect(() => {
    if (!generating) {
      const processing = videos.find((v) => v.status === 'processing');
      if (processing) {
        setGenerating(true);
        setGenStartedAt(new Date(processing.created_at).getTime());
        startPolling(processing.id, new Date(processing.created_at).getTime());
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videos.length]);

  const generate = async () => {
    setGenError(null);
    if (!prompt.trim()) {
      setGenError('Please describe the video you want.');
      return;
    }
    setGenerating(true);
    try {
      const token = await getAccessToken();
      const body = await callFunction<{ video: Video }>(
        'generate-video',
        { prompt, style, duration, aspect_ratio: aspect },
        token,
      );
      setVideos((prev) => [body.video, ...prev]);
      const startedAt = Date.now();
      setGenStartedAt(startedAt);
      startPolling(body.video.id, startedAt);
    } catch (err) {
      setGenerating(false);
      setGenStartedAt(null);
      setGenError(err instanceof Error ? err.message : 'Something went wrong.');
    }
  };

  const elapsed = genStartedAt ? Date.now() - genStartedAt : 0;
  const processingCount = videos.filter((v) => v.status === 'processing').length;

  return (
    <div className="space-y-8">
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Film className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-semibold">Create a Video</h1>
        </div>
        <div className="bg-[#141018]/80 border border-white/10 rounded-2xl p-6 space-y-5">
          <div>
            <label className="block text-sm text-zinc-300 mb-2">Describe your video</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A drone shot flying over a neon-lit city at night, rain on the streets..."
              rows={3}
              className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20 transition resize-none"
            />
          </div>

          <div className="grid sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-2">Style</label>
              <div className="flex flex-wrap gap-1.5">
                {STYLES.map((s) => (
                  <button
                    key={s}
                    onClick={() => setStyle(s)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 ${
                      style === s
                        ? 'bg-gradient-to-r from-purple-700 to-gold-500 text-white shadow-md shadow-gold-600/25'
                        : 'bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:border-white/25'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-2">Duration</label>
              <div className="flex gap-1.5">
                {DURATIONS.map((d) => (
                  <button
                    key={d}
                    onClick={() => setDuration(d)}
                    className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 ${
                      duration === d
                        ? 'bg-gradient-to-r from-purple-700 to-gold-500 text-white shadow-md shadow-gold-600/25'
                        : 'bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:border-white/25'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-2">Aspect Ratio</label>
              <div className="flex flex-col gap-1.5">
                {ASPECTS.map((a) => (
                  <button
                    key={a.value}
                    onClick={() => setAspect(a.value)}
                    className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 text-left ${
                      aspect === a.value
                        ? 'bg-gradient-to-r from-purple-700 to-gold-500 text-white shadow-md shadow-gold-600/25'
                        : 'bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:border-white/25'
                    }`}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {genError && (
            <div className="flex items-start gap-2 text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2.5">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{genError}</span>
            </div>
          )}

          {generating && (
            <div className="flex items-center gap-3 bg-gold-500/10 border border-gold-500/20 rounded-xl px-4 py-3">
              <Loader2 className="w-4 h-4 animate-spin text-gold-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gold-200">{stageFor(elapsed)}</p>
                <div className="mt-1.5 h-1 bg-black/40 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-gold-500 rounded-full transition-all duration-1000"
                    style={{ width: `${Math.min(95, (elapsed / TIMEOUT_MS) * 100)}%` }}
                  />
                </div>
                <p className="text-[11px] text-zinc-400 mt-1">
                  This usually takes 2–4 minutes. You can leave this page — your video will appear below.
                </p>
              </div>
            </div>
          )}

          <button
            onClick={generate}
            disabled={generating}
            className="w-full py-3.5 rounded-xl font-semibold bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 shadow-lg shadow-gold-600/25 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {generating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Film className="w-5 h-5" />
                Generate Video
              </>
            )}
          </button>
          {!generating && (
            <p className="text-xs text-zinc-500 text-center">1 UNIVERSA Coin is deducted only when the video succeeds.</p>
          )}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">My Videos</h2>
            {processingCount > 0 && (
              <span className="text-xs bg-gold-500/15 text-gold-300 border border-gold-500/25 px-2 py-0.5 rounded-full">
                {processingCount} processing
              </span>
            )}
          </div>
          <button
            onClick={() => void loadVideos()}
            className="text-sm text-zinc-400 hover:text-white transition"
          >
            Refresh
          </button>
        </div>

        {videos.length === 0 ? (
          <div className="border border-dashed border-white/10 rounded-2xl py-14 text-center text-zinc-500">
            <Film className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p>No videos yet. Describe one above and hit Generate.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            {videos.map((v) => <VideoCard key={v.id} video={v} />)}
          </div>
        )}
        {loadingVideos && <p className="text-xs text-zinc-500 mt-2">Loading…</p>}
      </section>
    </div>
  );
}
