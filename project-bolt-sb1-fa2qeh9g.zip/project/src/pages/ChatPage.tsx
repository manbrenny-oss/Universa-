import { useEffect, useState, useCallback, useRef } from 'react';
import { Loader2, MessageCircle, Send } from 'lucide-react';
import { supabase, type ChatMessage, type Character } from '@/lib/supabase';

export default function ChatPage() {
  const [contacts, setContacts] = useState<Character[]>([]);
  const [activeContact, setActiveContact] = useState<Character | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [myId, setMyId] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  // UNIVERSA chats start from characters — they act as personas to talk with.
  // We pair the sender with the character's owner so the messages are real DMs.
  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setMyId(user?.id ?? null);
      const { data } = await supabase
        .from('characters')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(30);
      setContacts((data ?? []) as Character[]);
      setLoading(false);
    };
    void init();
  }, []);

  const openChat = useCallback(async (character: Character) => {
    setActiveContact(character);
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .or(`and(sender_id.eq.${character.user_id},receiver_id.eq.${myId}),and(sender_id.eq.${myId},receiver_id.eq.${character.user_id})`)
      .order('created_at', { ascending: true })
      .limit(100);
    setMessages((data ?? []) as ChatMessage[]);
  }, [myId]);

  useEffect(() => {
    if (!myId || !activeContact) return;
    const channel = supabase
      .channel(`chat-${activeContact.user_id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chat_messages' },
        (payload) => {
          const msg = payload.new as ChatMessage;
          const relevant =
            (msg.sender_id === activeContact.user_id && msg.receiver_id === myId) ||
            (msg.sender_id === myId && msg.receiver_id === activeContact.user_id);
          if (relevant) setMessages((prev) => [...prev, msg]);
        },
      )
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [myId, activeContact]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const body = draft.trim();
    if (!body || !activeContact || !myId || activeContact.user_id === myId) return;
    setSending(true);
    const { error: sendError } = await supabase.from('chat_messages').insert({
      receiver_id: activeContact.user_id,
      body,
    });
    setSending(false);
    if (sendError) {
      // Realtime insert may be pending — surface nothing if it went through
      if (!sendError.message.includes('row-level security')) setDraft(body);
    } else {
      setDraft('');
    }
  };

  return (
    <div className="space-y-6">
      <section>
        <div className="flex items-center gap-2 mb-1">
          <MessageCircle className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-semibold">Chat</h1>
        </div>
        <p className="text-sm text-zinc-400">Message the creators behind the characters.</p>
      </section>

      {loading ? (
        <div className="py-12 flex justify-center"><Loader2 className="w-7 h-7 animate-spin text-gold-500" /></div>
      ) : contacts.length === 0 ? (
        <div className="border border-dashed border-white/10 rounded-2xl py-14 text-center text-zinc-500">
          <MessageCircle className="w-8 h-8 mx-auto mb-3 opacity-40" />
          <p>No one to chat with yet. Characters appear here once created.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-[220px_1fr] gap-4">
          <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
            {contacts.map((c) => (
              <button
                key={c.id}
                onClick={() => void openChat(c)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition text-left ${
                  activeContact?.id === c.id ? 'bg-gold-500/15 border border-gold-500/30' : 'bg-white/5 border border-white/10 hover:bg-white/10'
                }`}
              >
                {c.image_url ? (
                  <img src={c.image_url} alt={c.name} className="w-9 h-9 rounded-full object-cover" />
                ) : (
                  <span className="w-9 h-9 rounded-full bg-gradient-to-br from-purple-700 to-gold-500 flex items-center justify-center text-sm font-bold">
                    {c.name.charAt(0).toUpperCase()}
                  </span>
                )}
                <span className="min-w-0">
                  <span className="block text-sm font-medium truncate">{c.name}</span>
                  {c.tagline && <span className="block text-[11px] text-zinc-500 truncate">{c.tagline}</span>}
                </span>
              </button>
            ))}
          </div>

          <div className="bg-[#141018]/80 border border-white/10 rounded-2xl flex flex-col h-[420px]">
            {activeContact ? (
              <>
                <div className="px-4 py-3 border-b border-white/10">
                  <p className="text-sm font-medium">{activeContact.name}</p>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
                  {messages.length === 0 && (
                    <p className="text-xs text-zinc-500 text-center mt-8">Say hello — messages appear here instantly.</p>
                  )}
                  {messages.map((m) => (
                    <div key={m.id} className={`flex ${m.sender_id === myId ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-[75%] px-3.5 py-2 rounded-2xl text-sm ${
                          m.sender_id === myId
                            ? 'bg-gradient-to-r from-purple-700 to-gold-500 text-white rounded-br-sm'
                            : 'bg-white/10 text-zinc-200 rounded-bl-sm'
                        }`}
                      >
                        {m.body}
                      </div>
                    </div>
                  ))}
                  <div ref={bottomRef} />
                </div>
                <form onSubmit={send} className="p-3 border-t border-white/10 flex gap-2">
                  <input
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder={activeContact.user_id === myId ? "This is your own character" : "Type a message..."}
                    disabled={activeContact.user_id === myId}
                    className="flex-1 bg-black/30 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder-zinc-500 focus:outline-none focus:border-gold-500/60 transition text-sm disabled:opacity-50"
                  />
                  <button
                    type="submit"
                    disabled={sending || !draft.trim() || activeContact.user_id === myId}
                    className="px-4 rounded-xl bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 text-white transition disabled:opacity-50"
                    aria-label="Send message"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-sm text-zinc-500">
                Pick a conversation to start chatting.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
