import { useEffect, useState, useCallback } from 'react';
import { Loader2, Check, ShieldCheck, Zap, Coins, Gift, History, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getAccessToken, callFunction } from '@/lib/api';
import EarnPage from '@/pages/EarnPage';

const CREDIT_PACKAGES = [
  {
    id: 'starter',
    name: 'Starter',
    coins: 500,
    priceLabel: '$8',
    blurb: 'Great for trying out new ideas',
    perks: ['500 Coins', 'All styles & aspect ratios', 'HD downloads'],
    badge: null as string | null,
    coinCost: null as number | null,
  },
  {
    id: 'pro',
    name: 'Pro',
    coins: 2000,
    priceLabel: '$12',
    blurb: 'For the dedicated creator',
    perks: ['2,000 Coins', 'All styles & aspect ratios', 'HD downloads', 'Priority queue'],
    badge: 'Most Popular',
    coinCost: 1200,
  },
  {
    id: 'studio',
    name: 'Studio',
    coins: 6000,
    priceLabel: '$18',
    blurb: 'For agencies & heavy usage',
    perks: ['6,000 Coins', 'All styles & aspect ratios', 'HD downloads', 'Priority queue'],
    badge: 'Best Value',
    coinCost: 1800,
  },
];

interface LedgerRow {
  id: string;
  amount: number;
  kind: string;
  description: string;
  created_at: string;
}

type Tab = 'buy' | 'earn' | 'history';

export default function WalletPage({
  coins,
  onPurchaseComplete,
}: {
  coins: number | null;
  onPurchaseComplete: (newCoins: number) => void;
}) {
  const [tab, setTab] = useState<Tab>('buy');
  const [buying, setBuying] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [ledger, setLedger] = useState<LedgerRow[]>([]);
  const [loadingLedger, setLoadingLedger] = useState(false);

  const loadLedger = useCallback(async () => {
    setLoadingLedger(true);
    const { data } = await supabase
      .from('coin_ledger')
      .select('id, amount, kind, description, created_at')
      .order('created_at', { ascending: false })
      .limit(50);
    setLedger((data ?? []) as LedgerRow[]);
    setLoadingLedger(false);
  }, []);

  useEffect(() => {
    if (tab === 'history') void loadLedger();
  }, [tab, loadLedger]);

  // Resume Paystack verification after returning from checkout
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (params.get('payment') === 'success' && ref) {
      params.delete('payment');
      params.delete('ref');
      window.history.replaceState({}, '', `${window.location.pathname}${params.toString() ? `?${params}` : ''}`);
      void verifyPayment(ref);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refreshBalance = async () => {
    const { data } = await supabase.from('profiles').select('credits').limit(1).maybeSingle();
    if (data) onPurchaseComplete(data.credits);
  };

  const verifyPayment = async (reference: string) => {
    setVerifying(true);
    setError(null);
    try {
      const token = await getAccessToken();
      const body = await callFunction<{ paid?: boolean; credits?: number; error?: string }>(
        'paystack-verify',
        { reference },
        token,
      );
      if (body.paid) {
        if (typeof body.credits === 'number') onPurchaseComplete(body.credits);
        setNotice('Payment successful — your UNIVERSA Coins have been added!');
      } else {
        setNotice('Your payment is still being processed. Your coins will appear shortly.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not verify your payment.');
    } finally {
      setVerifying(false);
    }
  };

  const buyWithCash = async (packageId: string) => {
    setError(null);
    setNotice(null);
    setBuying(packageId);
    try {
      const token = await getAccessToken();
      const body = await callFunction<{ authorizationUrl?: string; error?: string }>(
        'paystack-initialize',
        { packageId },
        token,
      );
      if (!body.authorizationUrl) throw new Error(body.error ?? 'Could not start checkout.');
      window.location.href = body.authorizationUrl;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
      setBuying(null);
    }
  };

  const buyWithCoins = async (packageId: string) => {
    setError(null);
    setNotice(null);
    setBuying(packageId);
    try {
      // Create the order first via the same initialize endpoint, then pay with coins
      const token = await getAccessToken();
      const body = await callFunction<{ authorizationUrl?: string; reference?: string; error?: string }>(
        'paystack-initialize',
        { packageId, coinOnly: true },
        token,
      );
      if (!body.reference) throw new Error(body.error ?? 'Could not start coin checkout.');
      const { data: redeemed, error: rpcError } = await supabase.rpc('redeem_coins_for_order', {
        p_reference: body.reference,
      });
      if (rpcError) throw new Error(rpcError.message);
      if (redeemed) {
        await refreshBalance();
        setNotice('Paid with Coins — your pack has been added!');
      } else {
        setError('Not enough Coins for this pack. Earn more in the Earn tab.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
    } finally {
      setBuying(null);
    }
  };

  return (
    <div className="space-y-8">
      <section>
        <div className="flex items-center gap-2 mb-1">
          <Coins className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-semibold">Wallet</h1>
        </div>
        <p className="text-sm text-zinc-400">UNIVERSA Coins power every video, swap, and pack.</p>
      </section>

      <section className="rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-br from-purple-900/60 via-[#141018] to-[#0A0A0A] p-6 sm:p-8 relative">
        <div className="absolute -top-16 -right-16 w-48 h-48 bg-gold-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-700 to-gold-500 flex items-center justify-center shadow-lg shadow-gold-600/30">
            <Coins className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest text-gold-400 font-semibold">Coin Balance</p>
            <p className="text-3xl font-bold">{coins ?? '…'}</p>
          </div>
        </div>
      </section>

      <div className="flex gap-2 p-1 bg-black/30 rounded-xl">
        {([
          ['buy', 'Buy', Zap],
          ['earn', 'Earn', Gift],
          ['history', 'History', History],
        ] as const).map(([id, label, Icon]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 flex items-center justify-center gap-1.5 ${
              tab === id
                ? 'bg-gradient-to-r from-purple-700 to-gold-500 text-white shadow-md shadow-gold-600/25'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {tab === 'buy' && (
        <section className="space-y-6">
          {verifying && (
            <div className="flex items-center gap-3 bg-gold-500/10 border border-gold-500/20 rounded-xl px-4 py-3">
              <Loader2 className="w-4 h-4 animate-spin text-gold-400 shrink-0" />
              <p className="text-sm text-gold-200">Confirming your payment and adding coins...</p>
            </div>
          )}
          {notice && (
            <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-4 py-3">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <p className="text-sm text-emerald-200">{notice}</p>
            </div>
          )}
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm text-red-300">{error}</div>
          )}

          <div className="grid sm:grid-cols-3 gap-5">
            {CREDIT_PACKAGES.map((pkg) => (
              <div
                key={pkg.id}
                className={`relative rounded-2xl p-5 flex flex-col border transition-all duration-200 ${
                  pkg.badge
                    ? 'bg-gradient-to-b from-gold-600/15 to-[#141018]/90 border-gold-500/40 shadow-lg shadow-gold-600/10'
                    : 'bg-[#141018]/80 border-white/10 hover:border-white/25'
                }`}
              >
                {pkg.badge && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-[11px] font-semibold uppercase tracking-wide bg-gradient-to-r from-purple-700 to-gold-500 px-3 py-1 rounded-full whitespace-nowrap">
                    {pkg.badge}
                  </span>
                )}
                <h3 className="text-lg font-semibold">{pkg.name}</h3>
                <div className="mt-2">
                  <span className="text-3xl font-bold">{pkg.priceLabel}</span>
                  {pkg.coinCost !== null && (
                    <span className="text-sm text-gold-300 ml-2">or {pkg.coinCost.toLocaleString()} Coins</span>
                  )}
                </div>
                <p className="text-sm text-zinc-400 mt-1.5">
                  {pkg.coins.toLocaleString()} coins · {pkg.blurb}
                </p>
                <ul className="mt-4 space-y-2 flex-1">
                  {pkg.perks.map((perk) => (
                    <li key={perk} className="flex items-start gap-2 text-sm text-zinc-300">
                      <Check className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                      {perk}
                    </li>
                  ))}
                </ul>
                <div className="mt-5 space-y-2">
                  <button
                    onClick={() => void buyWithCash(pkg.id)}
                    disabled={buying !== null || verifying}
                    className="w-full py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-600 hover:to-gold-400 shadow-lg shadow-gold-600/25 text-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {buying === pkg.id ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Opening checkout...
                      </>
                    ) : (
                      `Pay ${pkg.priceLabel}`
                    )}
                  </button>
                  {pkg.coinCost !== null && (
                    <button
                      onClick={() => void buyWithCoins(pkg.id)}
                      disabled={buying !== null || verifying}
                      className="w-full py-2.5 rounded-xl font-semibold text-sm bg-white/5 border border-gold-500/30 hover:bg-white/10 text-gold-200 transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      <Coins className="w-4 h-4" />
                      Pay {pkg.coinCost.toLocaleString()} Coins
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-2 text-xs text-zinc-500">
            <ShieldCheck className="w-4 h-4" />
            Cash payments are processed securely by Paystack in USD.
          </div>
        </section>
      )}

      {tab === 'earn' && <EarnPage onCoinsChanged={onPurchaseComplete} />}

      {tab === 'history' && (
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Coin Transactions</h2>
            <button onClick={() => void loadLedger()} className="text-sm text-zinc-400 hover:text-white transition">
              Refresh
            </button>
          </div>
          {loadingLedger ? (
            <div className="py-12 flex justify-center"><Loader2 className="w-7 h-7 animate-spin text-gold-500" /></div>
          ) : ledger.length === 0 ? (
            <div className="border border-dashed border-white/10 rounded-2xl py-14 text-center text-zinc-500">
              <History className="w-8 h-8 mx-auto mb-3 opacity-40" />
              <p>No transactions yet. Earn or buy coins to get started.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {ledger.map((row) => {
                const earned = row.amount > 0;
                return (
                  <div key={row.id} className="bg-[#141018]/80 border border-white/10 rounded-xl px-4 py-3 flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                        earned ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'
                      }`}
                    >
                      {earned ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-zinc-200 truncate">{row.description}</p>
                      <p className="text-[11px] text-zinc-500">
                        {new Date(row.created_at).toLocaleDateString()} · {row.kind.replace(/_/g, ' ')}
                      </p>
                    </div>
                    <span className={`shrink-0 text-sm font-bold ${earned ? 'text-emerald-400' : 'text-red-400'}`}>
                      {earned ? '+' : ''}{row.amount}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
