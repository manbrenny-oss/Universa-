import { useEffect, useState, useCallback } from 'react';
import { Loader2, RefreshCw, Film, Play } from 'lucide-react';
import VideoCard from '@/components/VideoCard';
import { fetchVideos } from '@/lib/api';
import { supabase, type Video, type Character } from '@/lib/supabase';

const QUICK_MOODS = ['Trending', 'Cinematic', 'Anime', 'Realistic', '3D Render', 'Documentary'];

export default function HomePage({ onOpenCreate }: { onOpenCreate: () => void }) {
  const [videos, setVideos] = useState<Video[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);
  const [mood, setMood] = useState('Trending');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setVideos(await fetchVideos(20));
      const { data } = await supabase
        .from('characters')
        .select('*')
        .eq('is_public', true)
        .order('created_at', { ascending: false })
        .limit(10);
      setCharacters((data ?? []) as Character[]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const shown = mood === 'Trending' ? videos : videos.filter((v) => v.style === mood);

  return (
    <div className="space-y-8">
      <section>
        <div className="rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-br from-purple-900/60 via-[#141018] to-[#0A0A0A] p-6 sm:p-10 relative">
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-gold-600/20 rounded-full blur-3xl pointer-events-none" />
          <p className="text-xs font-semibold uppercase tracking-widest text-gold-400">Your World, Live</p>
          <h1 className="text-2xl sm:text-3xl font-bold mt-2 tracking-tight">Create. Swap. Go Live.</h1>
          <p className="text-zinc-400 text-sm mt-2 max-w-md">
            Generate AI videos, swap into any character, and share it with the community — all in one place.
          </p>
          <button
            onClick={onOpenCreate}
            className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-white bg-gradient-to-r from-purple-700 to-gold-500 hover:from-purple-500 hover:to-gold-500 shadow-lg shadow-gold-600/25 transition-all duration-200 px-5 py-2.5 rounded-xl"
          >
            <Film className="w-4 h-4" />
            Create a Video
          </button>
        </div>
      </section>

      {characters.length > 0 && (
        <section>
          <h2 className="text-lg font-semibold mb-3">Characters to Swap Into</h2>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1">
            {characters.map((c) => (
              <div key={c.id} className="shrink-0 w-28">
                <div className="w-28 h-28 rounded-2xl overflow-hidden border border-white/10 bg-purple-900/30">
                  {c.image_url ? (
                    <img src={c.image_url} alt={c.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-2xl font-bold text-gold-400/60">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
                <p className="text-xs text-zinc-300 mt-1.5 truncate">{c.name}</p>
                {c.tagline && <p className="text-[11px] text-zinc-500 truncate">{c.tagline}</p>}
              </div>
            ))}
          </div>
        </section>
      )}

      <section>
        <div className="flex items-center justify-between mb-4 gap-3">
          <h2 className="text-lg font-semibold">Community Videos</h2>
          <button onClick={() => void load()} className="flex items-center gap-1.5 text-sm text-zinc-400 hover:text-white transition">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
          {QUICK_MOODS.map((m) => (
            <button
              key={m}
              onClick={() => setMood(m)}
              className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all duration-150 ${
                mood === m
                  ? 'bg-gradient-to-r from-purple-700 to-gold-500 text-white shadow-md shadow-gold-600/25'
                  : 'bg-white/5 border border-white/10 text-zinc-400 hover:text-white'
              }`}
            >
              {m}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="py-16 flex justify-center"><Loader2 className="w-7 h-7 animate-spin text-gold-500" /></div>
        ) : shown.length === 0 ? (
          <div className="border border-dashed border-white/10 rounded-2xl py-16 text-center text-zinc-500">
            <Play className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p>No videos here yet. Be the first to create one!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            {shown.map((v) => <VideoCard key={v.id} video={v} />)}
          </div>
        )}
      </section>
    </div>
  );
}
