import { supabase, type Video } from '@/lib/supabase';

export async function getAccessToken(): Promise<string> {
  const { data: { session: s } } = await supabase.auth.getSession();
  if (!s) throw new Error('Please sign in first.');
  return s.access_token;
}

export async function callFunction<T>(
  name: string,
  body: Record<string, unknown>,
  token: string,
): Promise<T> {
  const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => null);
  if (!res.ok) throw new Error(json?.error ?? `Request failed (${res.status})`);
  return json as T;
}

export async function fetchVideos(limit = 30): Promise<Video[]> {
  const { data, error } = await supabase
    .from('videos')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw new Error(error.message);
  return (data ?? []) as Video[];
}

export async function fetchProfile() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase
    .from('profiles')
    .select('credits')
    .eq('id', user.id)
    .maybeSingle();
  return user;
}
