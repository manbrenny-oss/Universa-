import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Video {
  id: string;
  prompt: string;
  style: string;
  duration: string;
  aspect_ratio: string;
  status: 'processing' | 'completed' | 'failed';
  error_message: string | null;
  video_url: string | null;
  created_at: string;
}

export interface Character {
  id: string;
  user_id: string;
  name: string;
  tagline: string | null;
  image_url: string | null;
  is_public: boolean;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  sender_id: string;
  receiver_id: string;
  body: string;
  created_at: string;
}

export interface LiveRoom {
  id: string;
  host_id: string;
  title: string;
  status: 'live' | 'ended';
  viewers: number;
  started_at: string;
  ended_at: string | null;
}
