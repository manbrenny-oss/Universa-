import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const REPLICATE_API = "https://api.replicate.com/v1";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "You must be signed in to generate videos." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const prompt = (body.prompt ?? "").toString().trim();
    const style = (body.style ?? "Cinematic").toString();
    const duration = (body.duration ?? "5s").toString();
    const aspectRatio = (body.aspect_ratio ?? "16:9").toString();

    if (!prompt) {
      return new Response(JSON.stringify({ error: "Please describe the video you want." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check credits (read via own profile)
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("credits")
      .eq("id", user.id)
      .maybeSingle();

    if (profileError || !profile) {
      return new Response(JSON.stringify({ error: "Could not load your profile." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (profile.credits < 1) {
      return new Response(JSON.stringify({ error: "You are out of credits." }), {
        status: 402,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = Deno.env.get("REPLICATE_API_TOKEN");
    if (!token) {
      return new Response(JSON.stringify({ error: "REPLICATE_API_TOKEN is not configured." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const fullPrompt = `${prompt}. Style: ${style}. Duration: ${duration}. Aspect ratio: ${aspectRatio}.`;

    const replicateRes = await fetch(`${REPLICATE_API}/models/minimax/video-01/predictions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        "Prefer": "respond-async",
      },
      body: JSON.stringify({
        input: {
          prompt: fullPrompt,
          prompt_optimizer: true,
        },
      }),
    });

    const replicateData = await replicateRes.json().catch(() => null);

    if (!replicateRes.ok || !replicateData?.id) {
      const apiError = replicateData?.detail ?? replicateData?.title ?? `Replicate request failed (HTTP ${replicateRes.status})`;
      return new Response(JSON.stringify({ error: String(apiError) }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Save as processing — credit is deducted only after success
    const { data: video, error: insertError } = await supabase
      .from("videos")
      .insert({
        prompt,
        style,
        duration,
        aspect_ratio: aspectRatio,
        status: "processing",
        prediction_id: replicateData.id,
      })
      .select()
      .single();

    if (insertError || !video) {
      return new Response(JSON.stringify({ error: insertError?.message ?? "Could not save video record." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Award 10 coins for posting a video (service role, generic award)
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    await admin.rpc("award_coins", {
      p_user_id: user.id,
      p_amount: 10,
      p_kind: "post_video",
      p_description: "Posted a video",
      p_ref_id: video.id,
    });

    return new Response(JSON.stringify({ video }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err?.message ?? "Unexpected error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
