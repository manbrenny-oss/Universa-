import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const REPLICATE_API = "https://api.replicate.com/v1";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Not signed in." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { videoId } = await req.json();
    if (!videoId) {
      return new Response(JSON.stringify({ error: "Missing videoId." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: video, error: videoError } = await supabase
      .from("videos")
      .select("*")
      .eq("id", videoId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (videoError || !video) {
      return new Response(JSON.stringify({ error: "Video not found." }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (video.status !== "processing") {
      return new Response(JSON.stringify({ video }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 5 minute timeout
    const startedAt = new Date(video.created_at).getTime();
    if (Date.now() - startedAt > 5 * 60 * 1000) {
      await supabase
        .from("videos")
        .update({ status: "failed", error_message: "Generation timed out after 5 minutes." })
        .eq("id", video.id);
      return new Response(JSON.stringify({ video: { ...video, status: "failed", error_message: "Generation timed out after 5 minutes." } }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = Deno.env.get("REPLICATE_API_TOKEN");
    if (!token) {
      return new Response(JSON.stringify({ error: "REPLICATE_API_TOKEN is not configured." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const predRes = await fetch(`${REPLICATE_API}/predictions/${video.prediction_id}`, {
      headers: { "Authorization": `Bearer ${token}` },
    });
    const pred = await predRes.json().catch(() => null);

    if (!predRes.ok || !pred) {
      return new Response(JSON.stringify({ error: `Could not reach Replicate (HTTP ${predRes.status}).` }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (pred.status === "succeeded" && pred.output) {
      const videoUrl = Array.isArray(pred.output) ? pred.output[0] : String(pred.output);

      // Deduct 1 credit only after success (service role bypasses RLS)
      const admin = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      );
      const { data: profile } = await admin
        .from("profiles")
        .select("credits")
        .eq("id", user.id)
        .maybeSingle();
      if (profile && profile.credits > 0) {
        await admin.from("profiles").update({ credits: profile.credits - 1 }).eq("id", user.id);
      }

      const { data: updated } = await supabase
        .from("videos")
        .update({ status: "completed", video_url: videoUrl, completed_at: new Date().toISOString() })
        .eq("id", video.id)
        .select()
        .single();

      return new Response(JSON.stringify({ video: updated ?? { ...video, status: "completed", video_url: videoUrl } }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (pred.status === "failed" || pred.status === "canceled") {
      const errMsg = pred.error ? String(pred.error) : "Replicate reported the generation failed.";
      await supabase
        .from("videos")
        .update({ status: "failed", error_message: errMsg })
        .eq("id", video.id);
      return new Response(JSON.stringify({ video: { ...video, status: "failed", error_message: errMsg } }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ video }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err?.message ?? "Unexpected error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
