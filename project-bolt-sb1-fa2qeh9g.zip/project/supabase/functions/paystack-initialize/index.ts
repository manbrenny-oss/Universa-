import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const PACKAGES: Record<string, { credits: number; amountKobo: number; label: string }> = {
  // Paystack requires integer amounts in the currency's smallest unit.
  // USD smallest unit is cents; stored under the amountKobo key for schema reuse.
  starter: { credits: 500, amountKobo: 800, label: "Starter" },
  pro: { credits: 2000, amountKobo: 1200, label: "Pro" },
  studio: { credits: 6000, amountKobo: 1800, label: "Studio" },
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "You must be signed in to buy credits." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { packageId } = await req.json();
    const pkg = PACKAGES[String(packageId ?? "")];
    if (!pkg) {
      return new Response(JSON.stringify({ error: "Unknown credit package." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const secretKey = Deno.env.get("PAYSTACK_SECRET_KEY");
    if (!secretKey) {
      return new Response(JSON.stringify({ error: "Paystack is not configured yet." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const reference = `PV-${user.id.slice(0, 8)}-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;

    const { data: order, error: orderError } = await supabase
      .from("credit_orders")
      .insert({
        package_id: String(packageId),
        credits: pkg.credits,
        amount_kobo: pkg.amountKobo,
        paystack_reference: reference,
      })
      .select()
      .single();

    if (orderError || !order) {
      return new Response(JSON.stringify({ error: orderError?.message ?? "Could not create your order." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const origin = req.headers.get("Origin") ?? new URL(req.url).origin;
    const paystackRes = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: user.email,
        amount: pkg.amountKobo,
        currency: "USD",
        reference,
        metadata: { user_id: user.id, package_id: String(packageId) },
        callback_url: `${origin}/?payment=success&ref=${encodeURIComponent(reference)}`,
      }),
    });

    const paystackData = await paystackRes.json().catch(() => null);

    if (!paystackRes.ok || !paystackData?.status || !paystackData?.data?.authorization_url) {
      const apiError = paystackData?.message ?? `Paystack request failed (HTTP ${paystackRes.status})`;
      return new Response(JSON.stringify({ error: String(apiError) }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    await supabase
      .from("credit_orders")
      .update({ paystack_access_code: paystackData.data.access_code ?? null })
      .eq("id", order.id);

    return new Response(
      JSON.stringify({
        authorizationUrl: paystackData.data.authorization_url,
        reference,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: err?.message ?? "Unexpected error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
