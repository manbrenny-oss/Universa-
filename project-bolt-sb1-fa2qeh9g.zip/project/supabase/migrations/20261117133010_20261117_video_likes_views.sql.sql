/*
# Video likes and view counts

1. Modified Tables
- `videos`: add `likes` (integer, default 0), `views` (integer, default 0),
  and `viewers` (text array) to dedupe view counting per user session.

2. New Functions
- `like_video(p_video_id uuid)` — authenticated user toggles a like on any
  video; increments likes. Returns new count.
- `record_view(p_video_id uuid)` — records a view once per user per video
  (deduped via viewers array); increments views and auto-claims the 50-coin
  view milestone at 1000 views for the video owner. Returns new count.

3. Security
- Both functions SECURITY DEFINER, callable by `authenticated` only. RLS on
  videos already limits SELECT to the owner; Home feed shows only own videos
  for now, so likes/views apply to owner-visible videos.
*/

alter table public.videos add column if not exists likes integer not null default 0;
alter table public.videos add column if not exists views integer not null default 0;
alter table public.videos add column if not exists viewers text[] not null default '{}';

create or replace function public.like_video(p_video_id uuid)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_key text := 'like:' || v_user::text;
  v_likes integer;
begin
  if v_user is null then
    raise exception 'Not signed in';
  end if;

  update public.videos
  set likes = likes + 1,
      viewers = array_append(viewers, v_key)
  where id = p_video_id and not (v_key = any(viewers))
  returning likes into v_likes;

  if v_likes is null then
    select likes into v_likes from public.videos where id = p_video_id;
  end if;

  -- Auto-claim the 100-like milestone for the owner
  if v_likes >= 100 then
    perform public.claim_milestone('like_milestone', p_video_id::text);
  end if;

  return v_likes;
end;
$$;

revoke execute on function public.like_video(uuid) from public, anon;
grant execute on function public.like_video(uuid) to authenticated;

create or replace function public.record_view(p_video_id uuid)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_key text := 'view:' || coalesce(v_user::text, 'anon-' || gen_random_uuid()::text);
  v_views integer;
  v_owner uuid;
begin
  update public.videos
  set views = views + 1,
      viewers = array_append(viewers, v_key)
  where id = p_video_id and not (v_key = any(viewers))
  returning views, user_id into v_views, v_owner;

  if v_views is not null and v_views >= 1000 then
    perform public.claim_milestone('view_milestone', p_video_id::text);
  end if;

  return v_views;
end;
$$;

revoke execute on function public.record_view(uuid) from public, anon;
grant execute on function public.record_view(uuid) to authenticated;