/*
# UNIVERSA: characters, chat messages, live rooms, live presence

1. New Tables
- `characters` — user-created personas used by Character Swap.
  - `id`, `user_id` (owner, defaults to auth.uid()), `name`, `tagline`,
    `image_url`, `is_public` (share to feed), `created_at`.
- `chat_messages` — direct messages between users.
  - `id`, `sender_id`, `receiver_id`, `body`, `created_at`.
- `live_rooms` — a live broadcast session.
  - `id`, `host_id`, `title`, `status` ("live"/"ended"), `started_at`,
    `ended_at`, `viewers` (count).
- `live_presence` — one row per viewer in a live room (drives viewer list/count).
  - `room_id`, `user_id` (composite primary key), `joined_at`.

2. Security
- RLS enabled on all four tables.
- characters: owner-scoped SELECT/INSERT/UPDATE/DELETE for authenticated;
  public characters (is_public = true) readable by everyone signed in.
- chat_messages: sender and receiver can read; only sender can insert;
  messages immutable otherwise. No delete.
- live_rooms: all authenticated can read; only the host can insert, update
  (status/viewers) or delete own rooms.
- live_presence: viewers can insert/delete own presence rows and read anyone
  present in rooms they can see; updates to joined_at allowed on own row
  (heartbeat).
- Grants: authenticated only on all tables.

3. Notes
- The existing profiles (credits), videos, and credit_orders tables are
  unchanged. UNIVERSA Coins = the existing credits balance.
*/

create table if not exists public.characters (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  tagline text,
  image_url text,
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists characters_user_idx on public.characters (user_id, created_at desc);
create index if not exists characters_public_idx on public.characters (is_public, created_at desc);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create index if not exists chat_messages_pair_idx on public.chat_messages (sender_id, receiver_id, created_at);
create index if not exists chat_messages_receiver_idx on public.chat_messages (receiver_id, created_at desc);

create table if not exists public.live_rooms (
  id uuid primary key default gen_random_uuid(),
  host_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null,
  status text not null default 'live',
  viewers integer not null default 0,
  started_at timestamptz not null default now(),
  ended_at timestamptz
);

create index if not exists live_rooms_status_idx on public.live_rooms (status, started_at desc);

create table if not exists public.live_presence (
  room_id uuid not null references public.live_rooms(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

alter table public.characters enable row level security;
alter table public.chat_messages enable row level security;
alter table public.live_rooms enable row level security;
alter table public.live_presence enable row level security;

grant select, insert, update, delete on public.characters to authenticated;
grant select, insert on public.chat_messages to authenticated;
grant select, insert, update, delete on public.live_rooms to authenticated;
grant select, insert, update, delete on public.live_presence to authenticated;

-- characters
drop policy if exists "Users can view own characters" on public.characters;
create policy "Users can view own characters"
on public.characters for select
to authenticated
using (auth.uid() = user_id or is_public = true);

drop policy if exists "Users can create own characters" on public.characters;
create policy "Users can create own characters"
on public.characters for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can update own characters" on public.characters;
create policy "Users can update own characters"
on public.characters for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete own characters" on public.characters;
create policy "Users can delete own characters"
on public.characters for delete
to authenticated
using (auth.uid() = user_id);

-- chat_messages
drop policy if exists "Participants can read conversations" on public.chat_messages;
create policy "Participants can read conversations"
on public.chat_messages for select
to authenticated
using (auth.uid() = sender_id or auth.uid() = receiver_id);

drop policy if exists "Users can send messages" on public.chat_messages;
create policy "Users can send messages"
on public.chat_messages for insert
to authenticated
with check (auth.uid() = sender_id and sender_id <> receiver_id);

-- live_rooms
drop policy if exists "Signed in can view live rooms" on public.live_rooms;
create policy "Signed in can view live rooms"
on public.live_rooms for select
to authenticated
using (true);

drop policy if exists "Users can host live rooms" on public.live_rooms;
create policy "Users can host live rooms"
on public.live_rooms for insert
to authenticated
with check (auth.uid() = host_id);

drop policy if exists "Hosts can update own rooms" on public.live_rooms;
create policy "Hosts can update own rooms"
on public.live_rooms for update
to authenticated
using (auth.uid() = host_id)
with check (auth.uid() = host_id);

drop policy if exists "Hosts can delete own rooms" on public.live_rooms;
create policy "Hosts can delete own rooms"
on public.live_rooms for delete
to authenticated
using (auth.uid() = host_id);

-- live_presence
drop policy if exists "Viewers can read room presence" on public.live_presence;
create policy "Viewers can read room presence"
on public.live_presence for select
to authenticated
using (true);

drop policy if exists "Users can join rooms" on public.live_presence;
create policy "Users can join rooms"
on public.live_presence for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can heartbeat own presence" on public.live_presence;
create policy "Users can heartbeat own presence"
on public.live_presence for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can leave rooms" on public.live_presence;
create policy "Users can leave rooms"
on public.live_presence for delete
to authenticated
using (auth.uid() = user_id);