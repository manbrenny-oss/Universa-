/*
# UNIVERSA Coin economy: ledger, earning rules, coin checkout

1. New Tables
- `coin_ledger` — one row per coin movement (earn or spend).
  - `id`, `user_id` (defaults to auth.uid())
  - `amount` (integer, positive = earned, negative = spent)
  - `kind` (text): post_video | like_milestone | view_milestone |
    daily_login | invite_friend | swap_spend | coin_purchase
  - `description` (human-readable note)
  - `ref_id` (text, nullable) — dedupe key for milestone claims
  - `created_at`

2. New Functions (SECURITY DEFINER)
- `award_coins(p_user_id, p_amount, p_kind, p_description, p_ref_id)` —
  internal: appends a ledger row and updates the profile balance. Idempotent
  when p_ref_id is given (milestone dedupe). service_role only.
- `award_daily_login()` — caller claims their own daily bonus (5 coins), once
  per calendar day (UTC). Returns coins awarded (0 if already claimed).
- `award_invite(p_invitee_id uuid)` — grants the inviter 100 coins the first
  time a given invitee joins via their invite (deduped per invitee).
- `claim_milestone(p_kind text, p_ref_id text)` — caller claims a like/view
  milestone for their own video (20 coins per 100 likes, 50 per 1000 views).
  Deduped by ref_id; caller must own the video.
- `spend_coins(p_amount, p_kind, p_description)` — caller spends coins from
  their own balance; returns false if balance is insufficient.
- `redeem_coins_for_order(p_reference text)` — caller pays for a pending
  credit order with coins instead of cash (Pro = 1200, Studio = 1800; Starter
  is cash-only). Marks the order paid via complete_credit_order.

3. Security
- RLS on coin_ledger: users read own rows only; inserts happen only through
  the SECURITY DEFINER functions (no direct INSERT grant).
- Earn/spend functions callable by `authenticated` only; award_coins and
  award_invite by service_role only.

4. Notes
- Balances stay in profiles.credits — the ledger is the history.
*/

create table if not exists public.coin_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  amount integer not null,
  kind text not null,
  description text not null,
  ref_id text,
  created_at timestamptz not null default now()
);

create index if not exists coin_ledger_user_idx on public.coin_ledger (user_id, created_at desc);
create unique index if not exists coin_ledger_dedupe_idx
  on public.coin_ledger (user_id, kind, ref_id) where ref_id is not null;

alter table public.coin_ledger enable row level security;

grant select on public.coin_ledger to authenticated;

drop policy if exists "Users can view own ledger" on public.coin_ledger;
create policy "Users can view own ledger"
on public.coin_ledger for select
to authenticated
using (auth.uid() = user_id);

create or replace function public.award_coins(
  p_user_id uuid, p_amount integer, p_kind text, p_description text, p_ref_id text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_ref_id is not null then
    insert into public.coin_ledger (user_id, amount, kind, description, ref_id)
    values (p_user_id, p_amount, p_kind, p_description, p_ref_id)
    on conflict do nothing;
    if not found then return; end if;
  else
    insert into public.coin_ledger (user_id, amount, kind, description, ref_id)
    values (p_user_id, p_amount, p_kind, p_ref_id);
  end if;

  update public.profiles
  set credits = credits + p_amount
  where id = p_user_id;
end;
$$;

revoke execute on function public.award_coins(uuid, integer, text, text, text) from public, anon, authenticated;
grant execute on function public.award_coins(uuid, integer, text, text, text) to service_role;

create or replace function public.award_daily_login()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_today text := to_char(now() at time zone 'utc', 'YYYY-MM-DD');
begin
  if v_user is null then
    raise exception 'Not signed in';
  end if;

  insert into public.coin_ledger (user_id, amount, kind, description, ref_id)
  values (v_user, 5, 'daily_login', 'Daily login bonus', 'daily-' || v_today)
  on conflict do nothing;

  if not found then
    return 0;
  end if;

  update public.profiles set credits = credits + 5 where id = v_user;
  return 5;
end;
$$;

revoke execute on function public.award_daily_login() from public, anon;
grant execute on function public.award_daily_login() to authenticated;

create or replace function public.award_invite(p_invitee_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_inviter uuid;
begin
  select raw_user_meta_data->>'invited_by' into v_inviter
  from auth.users where id = p_invitee_id;

  if v_inviter is null or v_inviter = p_invitee_id then
    return;
  end if;

  insert into public.coin_ledger (user_id, amount, kind, description, ref_id)
  values (v_inviter, 100, 'invite_friend', 'Invited a friend', 'invite-' || p_invitee_id)
  on conflict do nothing;

  if found then
    update public.profiles set credits = credits + 100 where id = v_inviter;
  end if;
end;
$$;

revoke execute on function public.award_invite(uuid) from public, anon, authenticated;
grant execute on function public.award_invite(uuid) to service_role;

create or replace function public.claim_milestone(p_kind text, p_ref_id text)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_video public.videos;
  v_amount integer;
begin
  if v_user is null then
    raise exception 'Not signed in';
  end if;
  if p_kind not in ('like_milestone', 'view_milestone') then
    raise exception 'Unknown milestone type';
  end if;

  select * into v_video from public.videos where id = p_ref_id::uuid and user_id = v_user;
  if not found then
    raise exception 'Video not found';
  end if;

  v_amount := case when p_kind = 'like_milestone' then 20 else 50 end;

  insert into public.coin_ledger (user_id, amount, kind, description, ref_id)
  values (v_user, v_amount, p_kind,
    case when p_kind = 'like_milestone' then 'Video reached 100 likes' else 'Video reached 1000 views' end,
    p_ref_id)
  on conflict do nothing;

  if not found then
    return 0;
  end if;

  update public.profiles set credits = credits + v_amount where id = v_user;
  return v_amount;
end;
$$;

revoke execute on function public.claim_milestone(text, text) from public, anon;
grant execute on function public.claim_milestone(text, text) to authenticated;

create or replace function public.spend_coins(p_amount integer, p_kind text, p_description text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_balance integer;
begin
  if v_user is null then
    raise exception 'Not signed in';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'Invalid amount';
  end if;

  select credits into v_balance from public.profiles where id = v_user for update;

  if v_balance is null or v_balance < p_amount then
    return false;
  end if;

  update public.profiles set credits = credits - p_amount where id = v_user;

  insert into public.coin_ledger (user_id, amount, kind, description)
  values (v_user, -p_amount, p_kind, p_description);

  return true;
end;
$$;

revoke execute on function public.spend_coins(integer, text, text) from public, anon;
grant execute on function public.spend_coins(integer, text, text) to authenticated;

create or replace function public.redeem_coins_for_order(p_reference text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_order public.credit_orders;
  v_cost integer;
begin
  if v_user is null then
    raise exception 'Not signed in';
  end if;

  select * into v_order from public.credit_orders
  where paystack_reference = p_reference and user_id = v_user
  for update;

  if not found then
    raise exception 'Order not found';
  end if;
  if v_order.status = 'paid' then
    return true;
  end if;

  if v_order.package_id = 'pro' then
    v_cost := 1200;
  elsif v_order.package_id = 'studio' then
    v_cost := 1800;
  else
    raise exception 'This package is cash-only';
  end if;

  if (select credits from public.profiles where id = v_user for update) < v_cost then
    return false;
  end if;

  update public.profiles set credits = credits - v_cost where id = v_user;

  insert into public.coin_ledger (user_id, amount, kind, description)
  values (v_user, -v_cost, 'coin_purchase', 'Bought ' || v_order.package_id || ' pack with coins');

  perform public.complete_credit_order(p_reference, v_user);

  return true;
end;
$$;

revoke execute on function public.redeem_coins_for_order(text) from public, anon;
grant execute on function public.redeem_coins_for_order(text) to authenticated;