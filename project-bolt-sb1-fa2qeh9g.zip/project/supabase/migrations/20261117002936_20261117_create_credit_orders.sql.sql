/*
# Credit purchases via Paystack

1. New Tables
- `credit_orders` — one row per attempted credit purchase.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to the authenticated user)
  - `package_id` (text) — which credit package was bought (starter, pro, studio)
  - `credits` (integer) — how many credits the package grants
  - `amount_kobo` (integer) — price in kobo (Paystack's smallest unit)
  - `currency` (text) — payment currency, e.g. "NGN"
  - `paystack_reference` (text, unique) — the reference sent to Paystack
  - `paystack_access_code` (text) — checkout access code returned by Paystack
  - `status` (text) — "pending" or "paid"
  - `created_at`, `paid_at` (timestamps)

2. New Functions
- `complete_credit_order(p_reference text, p_user_id uuid)` — SECURITY DEFINER.
  Atomically flips a pending order to "paid" and adds its credits to the
  buyer's profile exactly once (returns true if it did the work). Only the
  service role can execute it.

3. Security
- Enable RLS on `credit_orders`.
- Grant: SELECT, INSERT to `authenticated` (owner-scoped). No updates or
  deletes — orders are immutable from the client; completion happens
  server-side through the edge function using the service role.
- Owner-scoped SELECT/INSERT policies via `auth.uid()`.
- EXECUTE on `complete_credit_order` granted to `service_role` only; revoked
  from `public`, `anon`, and `authenticated`.
*/

create table if not exists public.credit_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  package_id text not null,
  credits integer not null,
  amount_kobo integer not null,
  currency text not null default 'NGN',
  paystack_reference text not null unique,
  paystack_access_code text,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create index if not exists credit_orders_user_created_idx on public.credit_orders (user_id, created_at desc);
create index if not exists credit_orders_reference_idx on public.credit_orders (paystack_reference);

alter table public.credit_orders enable row level security;

grant select, insert on public.credit_orders to authenticated;

drop policy if exists "Users can view own orders" on public.credit_orders;
create policy "Users can view own orders"
on public.credit_orders for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can create own orders" on public.credit_orders;
create policy "Users can create own orders"
on public.credit_orders for insert
to authenticated
with check (auth.uid() = user_id);

-- Atomically mark an order paid and grant its credits exactly once
create or replace function public.complete_credit_order(p_reference text, p_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order public.credit_orders;
  v_updated record;
begin
  select * into v_order
  from public.credit_orders
  where paystack_reference = p_reference and user_id = p_user_id
  for update;

  if not found or v_order.status = 'paid' then
    return false;
  end if;

  update public.credit_orders
  set status = 'paid', paid_at = now()
  where id = v_order.id
  returning * into v_updated;

  update public.profiles
  set credits = credits + v_order.credits
  where id = p_user_id;

  return true;
end;
$$;

revoke execute on function public.complete_credit_order(text, uuid) from public, anon, authenticated;
grant execute on function public.complete_credit_order(text, uuid) to service_role;