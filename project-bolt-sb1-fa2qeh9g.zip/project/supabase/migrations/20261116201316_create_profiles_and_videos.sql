/*
# PromptVid: profiles with credits + videos table

1. New Tables
- `profiles` — one row per user, holding their credit balance.
  - `id` (uuid, primary key, matches auth.users id)
  - `email` (text)
  - `credits` (integer, default 3 free credits for new users)
  - `created_at` (timestamp)
- `videos` — one row per video generation request.
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to the authenticated user)
  - `prompt` (text) — what the user described
  - `style` (text) — Cinematic / Anime / Realistic / 3D Render / Documentary
  - `duration` (text) — "5s" or "10s"
  - `aspect_ratio` (text) — "16:9" or "9:16"
  - `status` (text) — "processing", "completed", or "failed"
  - `error_message` (text) — real error text when Replicate fails
  - `prediction_id` (text) — Replicate prediction id for polling
  - `video_url` (text) — final video file URL once complete
  - `created_at`, `completed_at` (timestamps)

2. Triggers
- `on_auth_user_created` — automatically creates a `profiles` row with 3 free
  credits whenever a new user signs up.

3. Security
- Enable RLS on both tables.
- Grant on `profiles`: SELECT, UPDATE (credits column only) to `authenticated`.
- Grant on `videos`: SELECT, INSERT, UPDATE, DELETE to `authenticated`.
- Owner-scoped policies on both tables via `auth.uid()`.

4. Notes
- Credits are deducted by the edge function using the service role, so the
  frontend never writes the balance directly.
*/

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  credits integer not null default 3,
  created_at timestamptz default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  prompt text not null,
  style text not null default 'Cinematic',
  duration text not null default '5s',
  aspect_ratio text not null default '16:9',
  status text not null default 'processing',
  error_message text,
  prediction_id text,
  video_url text,
  created_at timestamptz default now(),
  completed_at timestamptz
);

create index if not exists videos_user_id_created_idx on public.videos (user_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.videos enable row level security;

grant select, update (credits) on public.profiles to authenticated;
grant select, insert, update, delete on public.videos to authenticated;

drop policy if exists "Users can view own profile" on public.profiles;
create policy "Users can view own profile"
on public.profiles for select
to authenticated
using (auth.uid() = id);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

drop policy if exists "Users can view own videos" on public.videos;
create policy "Users can view own videos"
on public.videos for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can insert own videos" on public.videos;
create policy "Users can insert own videos"
on public.videos for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can update own videos" on public.videos;
create policy "Users can update own videos"
on public.videos for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete own videos" on public.videos;
create policy "Users can delete own videos"
on public.videos for delete
to authenticated
using (auth.uid() = user_id);

-- Auto-create a profile with 3 free credits on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, credits)
  values (new.id, new.email, 3)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

revoke execute on function public.handle_new_user() from public, anon;
