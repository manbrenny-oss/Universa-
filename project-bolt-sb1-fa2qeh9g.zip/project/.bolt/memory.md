# Project memory

## Product intent & audience

- **PromptVid**: signed-in video generation web app.
- Users spend credits to generate videos via Replicate.
- Monetization through credit packages purchased via Paystack (NGN).

## Brand personality & voice

- Production-grade, polished, non-cookie-cutter UI.
- Trust-oriented around payments and credit balances.

## Visual design & UX direction

- Vite + React + JSX, Tailwind CSS, Lucide React icons.
- `@/` path alias maps to `src/`.
- App shell has a header with credit counter and a "Buy Credits" action.
- Pricing page: 3 packages presented as cards (Starter, Pro, Studio).

## Decisions, constraints & rationale

- **Payments**: Paystack Live hosted checkout (not inline popup). Server verifies transactions before crediting.
- `PAYSTACK_SECRET_KEY` env var required; public key not needed because checkout is Paystack-hosted. UI shows "Paystack is not configured yet" when secret key is absent.
- **Packages** (prices/credits enforced server-side, not client-trusted):
  - Starter: ₦2,000 → 10 credits
  - Pro: ₦6,000 → 40 credits
  - Studio: ₦15,000 → 120 credits
- **Data**: `profiles` table holds credit balance; `credit_orders` table tracks purchases for idempotent crediting (safe across reloads, exactly-once).
- **Edge functions**: pre-existing Replicate video-generation functions; new Paystack `start-payment` and `verify-and-credit` functions.
- **Replicate**: API token already configured in environment; no changes needed.
- No UI/theme/icon packages beyond what the template provides.

## Open questions & assumptions

- Assumes Supabase auth + DB are the backend (profiles, edge functions, migrations).
- `PAYSTACK_SECRET_KEY` still needs to be added to the environment for live payments to work end-to-end.
- Currency assumed NGN; multi-currency not yet considered.
- No refund or failed-payment admin flow discussed yet.